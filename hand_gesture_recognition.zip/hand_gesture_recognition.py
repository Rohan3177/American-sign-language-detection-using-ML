# Load libraries
import cv2
import mediapipe as mp
import matplotlib.pyplot as plt
import numpy as np

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

# Initialize MediaPipe Pose
pose = mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Constants
MAX_ANGLE = 90
MIN_ANGLE = 30


def calculate_angle(a, b, c):
    '''Calculates the angle between three points using the law of cosines.'''
    vec_ab = np.array([b.x - a.x, b.y - a.y, b.z - a.z])
    vec_bc = np.array([c.x - b.x, c.y - b.y, c.z - b.z])
    dot_product = np.dot(vec_ab, vec_bc)
    magnitude_ab = np.linalg.norm(vec_ab)
    magnitude_bc = np.linalg.norm(vec_bc)
    cosine_angle = dot_product / (magnitude_ab * magnitude_bc)
    angle = np.arccos(cosine_angle) * 180 / np.pi
    return angle


def classify_sign(landmarks):
    '''Classifies a hand gesture into one of ten categories.'''
    # Extract coordinates of key points
    nose = landmarks['nose']
    left_eye = landmarks['left_eye']
    right_eye = landmarks['right_eye']
    left_ear = landmarks['left_ear']
    right_ear = landmarks['right_ear']
    mouth_center = landmarks['mouth_center']
    chin = landmarks['chin']

    # Calculate angles between joints
    angle_between_eyes = calculate_angle(left_eye, nose, right_eye)
    angle_between_ears = calculate_angle(left_ear, nose, right_ear)
    angle_between_nose_and_mouth_center = calculate_angle(nose, mouth_center, chin)

    # Classify gestures based on calculated angles
    if angle_between_eyes > MAX_ANGLE or \
            angle_between_ears > MAX_ANGLE or \
            angle_between_nose_and_mouth_center < MIN_ANGLE:
        return 'Fist'
    elif angle_between_eyes <= MAX_ANGLE and \
            angle_between_ears <= MAX_ANGLE and \
            angle_between_nose_and_mouth_center >= MIN_ANGLE:
        return 'Peace'
    else:
        raise ValueError("Invalid pose detected")


def detect_poses(frame):
    '''Detect poses in frame and draw bounding boxes around them.'''
    # Recolor image to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detect poses in the image
    results = pose.process(rgb_frame)

    # Get the landmark positions
    try:
        landmarks = results.pose_landmarks.landmark

        # For each detected pose, obtain the classification and draw its corresponding box
        for idx, lm in enumerate(landmarks):
            h, w, c = frame.shape
            x, y = int(lm.x * w), int(lm.y * h)
            cx, cy = round(w / 2), round(h / 2)

            # Draw a circle at each point
            cv2.circle(frame, (x, y), 5, (255, 0, 0), thickness=-1)

            # Obtain the classification for the current pose
            classification = classify_sign({
                'nose': landmarks[mp_pose.PoseLandmark.NOSE],
                'left_eye': landmarks[mp_pose.PoseLandmark.LEFT_EYE],
                'right_eye': landmarks[mp_pose.PoseLandmark.RIGHT_EYE],
                'left_ear': landmarks[mp_pose.PoseLandmark.LEFT_EAR],
                'right_ear': landmarks[mp_pose.PoseLandmark.RIGHT_EAR],
                'mouth_center': landmarks[mp_pose.PoseLandmark.MOUTH_CENTER],
                'chin': landmarks[mp_pose.PoseLandmark.CHIN]
            })

            # Write text indicating the classification below each point
            fontScale = 0.5
            bottomLeftCornerOfText = (
                int((idx % 10) * fontScale * cx + cx - (len(classification) / 2) * fontScale * cx),
                int(((idx // 10) + 1) * fontScale * cy + (cy // 2))
            )
            color = (255, 255, 255)
            lineType = cv2.LINE_AA
            cv2.putText(frame, str(classification), bottomLeftCornerOfText, cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale, color, 1, lineType)

        # Plot the resulting frame
        fig = plt.figure()
        ax = fig.add_subplot(projection="3d")
        ax.scatter3D(*zip(*[(lm.x, lm.y, lm.z) for lm in landmarks.values()]), s=100, marker='o', color='r')
        plt.imshow(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        plt.pause(0.001)

    except AttributeError:
        pass


if __name__ == "__main__":
    cv2.setUseOptimized(True)
    cv2.setNumThreads(0)
    cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        detect_poses(frame)
        k = cv2.waitKey(1) & 0xFF
        if k == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
